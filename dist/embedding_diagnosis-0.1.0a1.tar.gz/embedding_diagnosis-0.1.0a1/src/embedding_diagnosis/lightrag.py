"""Read-only adapter for an initialized, quiescent LightRAG Nano storage.

No LightRAG import or experimental provider is required. This alpha explicitly
depends on Nano's private dirty-state guards; it does not promise concurrent
writer safety or support other vector stores.
"""
from __future__ import annotations

from collections.abc import Mapping
from contextlib import nullcontext
from dataclasses import dataclass, field
import hashlib
import json
from pathlib import Path
import uuid

import numpy as np


@dataclass
class Observation:
    """One requested call scope, not a claim that an encoder executed."""

    call_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    events: list[dict] = field(default_factory=list)
    provider_calls: list[dict] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)


def vector_sha256(vector):
    return hashlib.sha256(np.asarray(vector, dtype="<f4").tobytes()).hexdigest()


class LightRAGAdapter:
    """Bind native storage, optional historical input proof and an observer.

    ``storage`` is normally ``initialized_rag.chunks_vdb``. ``provenance`` is
    an ID-to-proof mapping or JSON file path, not current configuration. An
    observer provides ``capture()`` yielding :class:`Observation`; only actual
    encoder executions associated with call ID and input position may be
    recorded as events. Without it, eligible records remain unknown and no
    potentially expensive unobservable embedding call is made.
    """

    _GUARDS = ("_pending_upserts", "_unsaved_upserts", "_pending_deletes",
               "_unsaved_deletes", "_client_dirty")

    def __init__(self, storage, *, observer=None, provenance=None):
        self.storage = storage
        self.observer = observer
        self.provenance = provenance
        self.observations = []

    def _require_snapshot(self):
        missing = [name for name in self._GUARDS if not hasattr(self.storage, name)]
        if missing:
            raise ValueError("Unsupported Nano snapshot guards: " + ", ".join(missing))
        dirty = [name for name in self._GUARDS if getattr(self.storage, name)]
        if dirty:
            raise ValueError("Reopen a flushed, quiescent index before diagnosis: " + ", ".join(dirty))

    def _read_provenance(self):
        source = self.provenance
        if source is None:
            return {}, "No historical embedding-input evidence was supplied."
        if isinstance(source, Mapping):
            return source, None
        try:
            result = json.loads(Path(source).read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}, "The historical embedding-input evidence file does not exist."
        except (OSError, UnicodeError, json.JSONDecodeError, TypeError) as exc:
            return {}, f"Historical embedding-input evidence is unreadable or malformed: {type(exc).__name__}: {exc}"
        if not isinstance(result, dict):
            return {}, "Historical embedding-input evidence must be an object keyed by native record ID."
        return result, None

    async def read_samples(self, sample_ids):
        self._require_snapshot()
        scope = self.observer.capture() if self.observer is not None else nullcontext(None)
        with scope as observed:
            records = await self.storage.get_by_ids(sample_ids)
            vectors = await self.storage.get_vectors_by_ids(sample_ids)
        self._require_snapshot()
        if observed is not None and (observed.events or observed.provider_calls):
            raise RuntimeError("Reading stored vectors unexpectedly invoked the embedding provider.")
        if not isinstance(records, (list, tuple)) or not isinstance(vectors, Mapping):
            raise TypeError("Unexpected native record/vector response structure.")
        provenance, global_issue = self._read_provenance()
        rows = []
        for record in records:
            if record is None:
                continue
            if not isinstance(record, Mapping):
                raise TypeError("Native record is not a mapping.")
            native_id = record.get("id")
            proof = provenance.get(native_id) if isinstance(native_id, str) else None
            issue = global_issue
            if not isinstance(proof, dict):
                proof = None
                issue = issue or "No valid historical embedding-input evidence exists for this record ID."
            rows.append({"id": native_id, "text": record.get("content"),
                         "vector": vectors.get(native_id), "input_proof": proof,
                         "provenance_issue": issue, "native_record": dict(record)})
        self.observations.append({"operation": "read_samples", "records": len(rows),
                                  "provenance_issue": global_issue})
        return rows

    async def embed_documents(self, requests):
        if self.observer is None:
            return [{"id": row["id"], "vector": None, "role": "document", "fresh": False,
                     "provider_event_ids": [], "observation_issue":
                     "No encoder observer is attached; native callable entry alone cannot establish freshness."}
                    for row in requests]
        with self.observer.capture() as observation:
            vectors = await self.storage.embedding_func(
                [row["text"] for row in requests], context="document"
            )
        array = np.asarray(vectors)
        if array.ndim != 2 or array.shape[0] != len(requests):
            raise ValueError(f"Native document output must have one row per input in input order; received {array.shape} for {len(requests)} inputs.")
        calls = observation.provider_calls
        scope_id = observation.call_id
        events = observation.events
        malformed_events = (not isinstance(events, list) or any(
            not isinstance(e, dict)
            or not isinstance(e.get("event_id"), str) or not e["event_id"]
            or e.get("call_id") != scope_id
            or not isinstance(e.get("input_position"), int)
            or isinstance(e.get("input_position"), bool)
            or not 0 <= e["input_position"] < len(requests)
            for e in events))
        call_ok = (isinstance(scope_id, str) and bool(scope_id)
                   and isinstance(calls, list) and len(calls) == 1 and isinstance(calls[0], dict)
                   and isinstance(calls[0].get("provider_call_id"), str) and bool(calls[0]["provider_call_id"])
                   and calls[0].get("call_id") == scope_id
                   and calls[0].get("status") == "completed"
                   and calls[0].get("input_count") == len(requests)
                   and calls[0].get("output_count") == len(requests))
        output = []
        for position, (request, vector) in enumerate(zip(requests, array, strict=True)):
            event = None
            issue = None
            if not call_ok:
                issue = "A single complete native provider call could not be associated with this replay; split or ambiguous calls are unsupported."
            elif malformed_events or any(e.get("provider_call_id") != calls[0]["provider_call_id"] for e in events):
                issue = "Encoder events contain invalid invocation identifiers or input positions."
            elif observation.issues:
                issue = "; ".join(observation.issues)
            else:
                matches = [e for e in observation.events
                           if e.get("call_id") == observation.call_id
                           and e.get("provider_call_id") == calls[0].get("provider_call_id")
                           and e.get("input_position") == position]
                if len(matches) != 1:
                    issue = "Encoder evidence is missing or ambiguous for this invocation and input position."
                else:
                    event = matches[0]
                    if event.get("execution_observed") is not True:
                        issue = "Actual local encoder execution was not observed."
                    elif event.get("output_sha256") != vector_sha256(vector):
                        issue = "The observed encoder output does not match this native output row."
            event = event or {}
            output.append({"id": request["id"], "vector": vector.tolist(),
                           "role": event.get("role"), "input_sha256": event.get("input_sha256"),
                           "fresh": issue is None, "provider_event_ids": [event["event_id"]] if issue is None else [],
                           "observation_issue": issue, "encoder_observation": event,
                           "call_id": observation.call_id, "input_position": position,
                           "native_call": "storage.embedding_func(texts, context='document')"})
        self.observations.append({"operation": "embed_documents", "call_id": observation.call_id,
                                  "provider_calls": calls, "encoder_events": observation.events,
                                  "issues": observation.issues})
        return output
