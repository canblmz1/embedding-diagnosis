"""Shared B adapter orchestration around the existing NumPy cosine mechanism.

Adapters own native storage access, original-input reconstruction and provider
instrumentation. Their evidence is observable local evidence, not authenticated
attestation or a guarantee about other workers or unexamined records.
"""
from collections import Counter
import hashlib
import math

import numpy as np

from ._comparison import check_drift

def _digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def _vector(value):
    try:
        array = np.asarray(value, dtype=np.float64)
    except (TypeError, ValueError, OverflowError):
        return None
    if array.ndim != 1 or array.size == 0 or not np.isfinite(array).all():
        return None
    if not math.isfinite(float(np.linalg.norm(array))) or float(np.linalg.norm(array)) == 0:
        return None
    return array.tolist()

def _proof_valid(sample):
    text = sample.get('text')
    proof = sample.get('input_proof')
    if not isinstance(text, str) or not isinstance(proof, dict):
        return False
    original = proof.get('embedding_input')
    return (isinstance(original, str)
            and proof.get('source_text_sha256') == _digest(text)
            and proof.get('input_sha256') == _digest(original)
            and proof.get('role') == 'document'
            and proof.get('reconstruction_verified') is True
            and isinstance(proof.get('preprocessing'), str)
            and bool(proof.get('preprocessing'))
            and isinstance(proof.get('evidence_ref'), str)
            and bool(proof.get('evidence_ref')))

async def diagnose(adapter, sample_ids, *, threshold):
    """Read chosen records, obtain current document outputs, and explain each ID.

Async adapter methods:
      read_samples(sample_ids) -> [{id,text,vector,input_proof,...}]
      embed_documents([{id,text}, ...]) ->
        [{id,vector,role,input_sha256,fresh,provider_event_ids,...}]

The input hash in a fresh result refers to the actual post-preprocessing
document provider input; the adapter must observe and expose its evidence.
"""
    ids = list(sample_ids)
    if not ids or any(not isinstance(i, str) or not i for i in ids) or len(ids) != len(set(ids)):
        raise ValueError('sample_ids must be nonempty unique strings')
    if not math.isfinite(threshold) or not -1 <= threshold <= 1:
        raise ValueError('threshold must be finite and within [-1, 1]')
    rows = {i:{'id':i,'status':'unknown','reason':'not_evaluated','cosine':None,
               'threshold':threshold,'stored_vector':None,'fresh_vector':None} for i in ids}
    try:
        stored = list(await adapter.read_samples(ids))
    except Exception as exc:
        for row in rows.values():
            row.update(reason='storage_read_error',error={'type':type(exc).__name__,'message':str(exc)})
        return _report(rows, threshold)
    usable_stored = [s for s in stored if isinstance(s, dict) and isinstance(s.get('id'), str)]
    frequencies = Counter(s['id'] for s in usable_stored)
    by_id = {s['id']:s for s in usable_stored}
    eligible = []
    for sample_id in ids:
        row = rows[sample_id]
        if frequencies[sample_id] != 1:
            row['reason'] = 'stored_id_missing_or_ambiguous'
            continue
        sample = by_id[sample_id]
        row['stored_evidence'] = sample
        if not _proof_valid(sample):
            row['reason'] = 'original_embedding_input_unverified'
            continue
        vector = _vector(sample.get('vector'))
        if vector is None:
            row['reason'] = 'stored_vector_unusable'
            continue
        row['stored_vector'] = vector
        eligible.append({'id':sample_id,'text':sample['text']})
    if not eligible:
        return _report(rows, threshold)
    try:
        fresh = list(await adapter.embed_documents(eligible))
    except Exception as exc:
        for sample in eligible:
            rows[sample['id']].update(reason='document_embedding_error',
                                    error={'type':type(exc).__name__,'message':str(exc)})
        return _report(rows, threshold)
    usable_fresh = [s for s in fresh if isinstance(s, dict) and isinstance(s.get('id'), str)]
    expected_ids = {s['id'] for s in eligible}
    if len(usable_fresh) != len(fresh) or any(s['id'] not in expected_ids for s in usable_fresh):
        for sample_id in expected_ids:
            rows[sample_id]['reason'] = 'fresh_output_contract_invalid'
        return _report(rows, threshold)
    frequencies = Counter(s['id'] for s in usable_fresh)
    by_fresh_id = {s['id']:s for s in usable_fresh}
    for sample in eligible:
        sample_id = sample['id']
        row = rows[sample_id]
        if frequencies[sample_id] != 1:
            row['reason'] = 'fresh_id_missing_or_ambiguous'
            continue
        current = by_fresh_id[sample_id]
        row['fresh_evidence'] = current
        if current.get('role') != 'document':
            row['reason'] = 'document_role_unverified'
            continue
        events = current.get('provider_event_ids')
        if (current.get('fresh') is not True or not isinstance(events, list) or not events
                or not all(isinstance(event, str) and event for event in events)):
            row['reason'] = 'fresh_backend_execution_unverified'
            continue
        proof = by_id[sample_id]['input_proof']
        if current.get('input_sha256') != proof['input_sha256']:
            row['reason'] = 'replayed_input_differs_from_verified_original'
            continue
        vector = _vector(current.get('vector'))
        if vector is None:
            row['reason'] = 'fresh_vector_unusable'
            continue
        row['fresh_vector'] = vector
        if len(vector) != len(row['stored_vector']):
            row.update(status='mismatch',reason='vector_dimension_mismatch')
            continue
        result = check_drift({'canaries':[{'probe':sample_id,'embedding':row['stored_vector']}]},
                             [{'probe':sample_id,'embedding':vector}],threshold=threshold)
        similarity = result['probes'][0]['similarity']
        if similarity is None or not math.isfinite(similarity):
            row['reason'] = 'comparator_result_unusable'
            continue
        match = result['ok']
        row.update(status='match' if match else 'mismatch',
                   reason='cosine_within_declared_tolerance' if match else 'not_reproduced_under_document_contract',
                   cosine=similarity)
    return _report(rows, threshold)

def _report(rows, threshold):
    values = list(rows.values())
    counts = Counter(row['status'] for row in values)
    return {'schema_version':1,'threshold':threshold,'samples':values,
            'counts':{state:counts[state] for state in ['match','mismatch','unknown']},
            'scope':'Only selected records and observed provider calls; no model identity, whole-index or worker-epoch guarantee.',
            'evidence_trust':'Native adapter observations; not authenticated provenance.'}
