"""Small readable summary of the JSON-compatible diagnostic report."""

_REASONS = {
    "original_embedding_input_unverified": "The original encoder input is not established; no replay was attempted.",
    "fresh_backend_execution_unverified": "Current local encoder execution was not established.",
    "document_role_unverified": "The observed embedding role is not established as document.",
    "replayed_input_differs_from_verified_original": "Observed replay input differs from the recorded original input.",
    "stored_id_missing_or_ambiguous": "The selected stored ID is missing or ambiguous.",
    "fresh_id_missing_or_ambiguous": "The replay ID could not be paired uniquely.",
    "fresh_output_contract_invalid": "The replay output violates the ID contract.",
    "stored_vector_unusable": "The stored vector is not usable for this comparison.",
    "fresh_vector_unusable": "The replay vector is not usable for this comparison.",
    "storage_read_error": "The native storage read failed.",
    "document_embedding_error": "The document call or its observation contract failed.",
    "vector_dimension_mismatch": "Stored and current document dimensions differ.",
    "not_reproduced_under_document_contract": "The selected vector was not reproduced within the declared tolerance.",
    "cosine_within_declared_tolerance": "The selected vector agrees within the declared cosine tolerance.",
    "comparator_result_unusable": "The numeric comparison did not yield a usable result.",
}


def summarize(report):
    """Return a short explanation without modifying the report or the index."""
    counts = report["counts"]
    lines = [
        f"Selected {len(report['samples'])} records: {counts['match']} match, "
        f"{counts['mismatch']} mismatch, {counts['unknown']} unknown.",
        f"Declared cosine threshold: {report['threshold']}",
    ]
    for row in report["samples"]:
        reason = row["reason"]
        lines.append(f"{row['id']}: {row['status']} — {_REASONS.get(reason, reason)}")
        if row.get("cosine") is not None:
            lines.append(f"  cosine={row['cosine']:.12g}")
        if row.get("error"):
            error = row["error"]
            lines.append(f"  {error['type']}: {error['message']}")
        for evidence_key, issue_key in [
            ("stored_evidence", "provenance_issue"),
            ("fresh_evidence", "observation_issue"),
        ]:
            issue = row.get(evidence_key, {}).get(issue_key)
            if issue:
                lines.append(f"  {issue}")
    lines.append("These decisions concern only the selected records and observed calls; they do not establish a model-change cause or certify the whole index.")
    return "\n".join(lines)
