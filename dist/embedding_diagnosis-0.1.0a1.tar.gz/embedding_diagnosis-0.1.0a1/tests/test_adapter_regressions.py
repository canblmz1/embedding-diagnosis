"""Two targeted adapter regressions; these doubles are not native/model evidence."""
from contextlib import contextmanager
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import unittest

import numpy as np

from embedding_diagnosis import diagnose
from embedding_diagnosis.lightrag import LightRAGAdapter, Observation, vector_sha256


TEXT = "Two different native IDs can contain the same text."
IDS = ["first-native-id", "second-native-id"]


def proof():
    digest = sha256(TEXT.encode()).hexdigest()
    return {"source_text_sha256": digest, "embedding_input": TEXT,
            "input_sha256": digest, "role": "document",
            "reconstruction_verified": True, "preprocessing": "unit regression identity",
            "evidence_ref": "unit-regression-write-observation"}


class UnitObserver:
    def __init__(self):
        self.current = None
        self.captures = []

    @contextmanager
    def capture(self):
        previous = self.current
        observed = Observation()
        self.current = observed
        self.captures.append(observed)
        try:
            yield observed
        finally:
            self.current = previous


class UnitStorage:
    """Tiny storage/call double to isolate the two defects, with no app imports."""

    def __init__(self, observer, mode="valid"):
        for name in LightRAGAdapter._GUARDS:
            setattr(self, name, False)
        self.observer = observer
        self.mode = mode
        self.calls = 0
        self.vectors = np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32)

    async def get_by_ids(self, ids):
        if self.mode == "read_error":
            raise OSError("actual native-read failure sentinel")
        return [{"id": sample_id, "content": TEXT} for sample_id in reversed(ids)]

    async def get_vectors_by_ids(self, ids):
        return {sample_id: self.vectors[IDS.index(sample_id)].tolist() for sample_id in ids}

    async def embedding_func(self, texts, *, context):
        self.calls += 1
        assert context == "document"
        assert texts == [TEXT, TEXT]
        observed = self.observer.current
        provider_id = observed.call_id + "-provider"
        observed.provider_calls.append({
            "call_id": observed.call_id, "provider_call_id": provider_id,
            "input_count": 2, "output_count": 2, "status": "completed", "role": context,
        })
        for position, vector in enumerate(self.vectors):
            observed.events.append({
                "call_id": observed.call_id, "provider_call_id": provider_id,
                "input_position": position, "event_id": f"{provider_id}:{position}",
                "role": context, "input_sha256": sha256(texts[position].encode()).hexdigest(),
                "execution_observed": True, "output_sha256": vector_sha256(vector),
            })
        if self.mode == "duplicate_position":
            observed.events[1]["input_position"] = 0
        elif self.mode == "unrelated_invocation":
            for event in observed.events:
                event["call_id"] = "different-call"
        elif self.mode == "short_output":
            return self.vectors[:1]
        return self.vectors.copy()


class AdapterRegressions(unittest.IsolatedAsyncioTestCase):
    async def test_missing_or_corrupt_history_is_not_a_storage_failure(self):
        with TemporaryDirectory() as folder:
            folder = Path(folder)
            bad_json = folder / "bad.json"
            bad_json.write_text("{not JSON")
            bad_shape = folder / "bad-shape.json"
            bad_shape.write_text(json.dumps(["not an ID-to-proof object"]))
            for provenance in [None, folder / "missing.json", bad_json, bad_shape]:
                with self.subTest(provenance=str(provenance)):
                    observer = UnitObserver()
                    storage = UnitStorage(observer)
                    report = await diagnose(LightRAGAdapter(storage, observer=observer,
                                                           provenance=provenance), IDS, threshold=0.99999)
                    self.assertEqual(report["counts"], {"match": 0, "mismatch": 0, "unknown": 2})
                    self.assertEqual(storage.calls, 0)
                    for row in report["samples"]:
                        self.assertEqual(row["reason"], "original_embedding_input_unverified")
                        self.assertEqual(row["stored_evidence"]["text"], TEXT)
                        self.assertTrue(row["stored_evidence"]["provenance_issue"])
            observer = UnitObserver()
            storage = UnitStorage(observer, mode="read_error")
            report = await diagnose(LightRAGAdapter(storage, provenance=folder / "missing.json"),
                                    IDS, threshold=0.99999)
            self.assertEqual(storage.calls, 0)
            for row in report["samples"]:
                self.assertEqual(row["reason"], "storage_read_error")
                self.assertIn("native-read failure sentinel", row["error"]["message"])

    async def test_duplicate_text_uses_invocation_and_input_position(self):
        provenance = {sample_id: proof() for sample_id in IDS}
        observer = UnitObserver()
        storage = UnitStorage(observer)
        report = await diagnose(LightRAGAdapter(storage, observer=observer, provenance=provenance),
                                IDS, threshold=0.99999)
        self.assertEqual(report["counts"], {"match": 2, "mismatch": 0, "unknown": 0})
        self.assertEqual(storage.calls, 1)
        self.assertEqual([row["id"] for row in report["samples"]], IDS)
        events = []
        for position, row in enumerate(report["samples"]):
            fresh = row["fresh_evidence"]
            self.assertEqual(fresh["input_position"], position)
            self.assertEqual(fresh["call_id"], observer.captures[-1].call_id)
            events.extend(fresh["provider_event_ids"])
        self.assertEqual(len(set(events)), 2)
        for failure in ["duplicate_position", "unrelated_invocation", "short_output"]:
            with self.subTest(failure=failure):
                observer = UnitObserver()
                storage = UnitStorage(observer, mode=failure)
                report = await diagnose(LightRAGAdapter(storage, observer=observer, provenance=provenance),
                                        IDS, threshold=0.99999)
                self.assertEqual(report["counts"], {"match": 0, "mismatch": 0, "unknown": 2})
                for row in report["samples"]:
                    self.assertTrue(row.get("error") or row.get("fresh_evidence", {}).get("observation_issue"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
