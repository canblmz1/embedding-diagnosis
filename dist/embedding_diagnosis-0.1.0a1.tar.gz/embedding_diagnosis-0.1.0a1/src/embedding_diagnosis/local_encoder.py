"""Optional observed local BERT-family sentence encoder.

This is a normal LightRAG embedding callable: ordered tokenizer input, actual
CPU model execution, attention-mask mean pooling, and ordered float32 output.
It has no embedding-output cache. Freshness is evidenced at the local encoder
module's completed forward hook, never by an API request or wrapper entry.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
import hashlib
import json
from pathlib import Path
import uuid

import numpy as np

from .lightrag import Observation, vector_sha256


class LocalTransformerEncoder:
    """CPU encoder/observer for the documented MiniLM BERT model path.

    Heavy dependencies are imported only on construction. ``model_path`` must
    already contain an authorized model and tokenizer. No automatic downloads,
    network calls, remote code, output caches or cache clearing occur here.
    This alpha uses one forward per call and does not internally reorder inputs.
    """

    def __init__(self, model_path, *, max_length=128, document_prefix="", query_prefix=""):
        import torch
        from transformers import AutoModel, AutoTokenizer

        self.torch = torch
        path = str(Path(model_path).resolve())
        self.tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True, trust_remote_code=False)
        self.model = AutoModel.from_pretrained(path, local_files_only=True, trust_remote_code=False,
                                             use_safetensors=True).to("cpu").eval()
        if not hasattr(self.model, "encoder"):
            raise ValueError("This alpha observer supports a BERT-family model exposing its encoder module.")
        self.max_length = max_length
        self.document_prefix = document_prefix
        self.query_prefix = query_prefix
        self.embedding_dim = int(self.model.config.hidden_size)
        source = Path(path)
        self.configuration = {
            "model_files_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                   for p in sorted(source.iterdir()) if p.is_file() and p.suffix in {".json", ".safetensors", ".txt"}},
            "max_length": max_length, "document_prefix": document_prefix, "query_prefix": query_prefix,
            "pooling": "attention-mask mean", "device": "cpu", "dtype": "float32", "use_cache": False,
        }
        self.configuration_sha256 = hashlib.sha256(json.dumps(self.configuration, sort_keys=True).encode()).hexdigest()
        self._capture = ContextVar(f"embedding_capture_{id(self)}", default=None)
        self._active_forward = ContextVar(f"embedding_forward_{id(self)}", default=None)
        self.provider_call_count = 0
        self.encoder_forward_count = 0
        self.encoded_text_count = 0
        self._hook = self.model.encoder.register_forward_hook(self._encoder_completed, with_kwargs=True)

    def __deepcopy__(self, memo):
        # LightRAG dataclasses.asdict traverses callable objects. Keep the actual
        # app-owned model/observer, including its ContextVars, instead of cloning
        # weights or creating an unobserved provider.
        return self

    @contextmanager
    def capture(self):
        observation = Observation()
        token = self._capture.set(observation)
        try:
            yield observation
        finally:
            self._capture.reset(token)

    def _encoder_completed(self, module, args, kwargs, output):
        active = self._active_forward.get()
        if active is None:
            return
        self.encoder_forward_count += 1
        active["forward_completions"] += 1
        states = output[0]
        active["encoder_output_shape"] = list(states.shape)
        active["forward_id"] = uuid.uuid4().hex

    async def __call__(self, texts, *, context="document"):
        if context not in {"document", "query"}:
            raise ValueError("context must be document or query")
        texts = list(texts)
        if any(not isinstance(text, str) for text in texts):
            raise TypeError("Embedding input must be an ordered sequence of strings.")
        if not texts:
            return np.empty((0, self.embedding_dim), dtype=np.float32)
        observation = self._capture.get()
        call_id = observation.call_id if observation is not None else uuid.uuid4().hex
        provider_call_id = uuid.uuid4().hex
        call = {"call_id": call_id, "provider_call_id": provider_call_id,
                "input_count": len(texts), "output_count": None, "status": "started", "role": context}
        if observation is not None:
            observation.provider_calls.append(call)
        self.provider_call_count += 1
        prefix = self.document_prefix if context == "document" else self.query_prefix
        inputs = [prefix + text for text in texts]
        encoded = self.tokenizer(inputs, padding=True, truncation=True,
                                 max_length=self.max_length, return_tensors="pt")
        active = {"forward_completions": 0}
        token = self._active_forward.set(active)
        try:
            with self.torch.inference_mode():
                model_output = self.model(**encoded, use_cache=False)
                token_embeddings = model_output.last_hidden_state
                mask = encoded["attention_mask"].unsqueeze(-1).expand(token_embeddings.size()).float()
                pooled = (token_embeddings * mask).sum(1) / mask.sum(1).clamp(min=1e-9)
            vectors = pooled.cpu().numpy().astype(np.float32, copy=False)
            if vectors.shape != (len(texts), self.embedding_dim):
                raise ValueError("Encoder returned an unexpected row count or dimension.")
            call.update(status="completed", output_count=len(vectors),
                        encoder_forward_completions=active["forward_completions"])
            self.encoded_text_count += len(texts)
            if observation is not None:
                if active["forward_completions"] != 1 or active.get("encoder_output_shape", [None])[0] != len(texts):
                    observation.issues.append("The expected single local encoder forward was not observed with the input batch size.")
                else:
                    for position, (text, vector) in enumerate(zip(inputs, vectors, strict=True)):
                        tensors = {name: value[position].tolist() for name, value in encoded.items()}
                        observation.events.append({
                            "event_id": f"{provider_call_id}:{position}", "call_id": call_id,
                            "provider_call_id": provider_call_id, "input_position": position,
                            "role": context, "embedding_input": text,
                            "input_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                            "output_sha256": vector_sha256(vector), "execution_observed": True,
                            "forward_id": active["forward_id"], "encoder_output_shape": active["encoder_output_shape"],
                            "tokenized_row": tensors, "max_length": self.max_length,
                            "encoder_configuration_sha256": self.configuration_sha256,
                            "pooling": "attention-mask mean", "device": "cpu", "use_cache": False,
                            "observation_boundary": "completed torch BERT encoder module forward; no embedding-output cache in this callable",
                        })
            return vectors
        except Exception as exc:
            call.update(status="failed", error=f"{type(exc).__name__}: {exc}")
            raise
        finally:
            self._active_forward.reset(token)

    def counts(self):
        return {"provider_calls": self.provider_call_count,
                "encoder_forwards": self.encoder_forward_count,
                "encoded_texts": self.encoded_text_count}

    def close(self):
        self._hook.remove()
