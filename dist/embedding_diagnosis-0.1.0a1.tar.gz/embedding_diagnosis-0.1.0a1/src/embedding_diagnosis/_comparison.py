"""Established NumPy comparison, retained without numerical changes."""
import numpy as np


def check_drift(fingerprint, fresh_canaries, threshold=0.98):
    fresh_by_probe = {c['probe']: c['embedding'] for c in fresh_canaries}
    probes = []
    for stored in fingerprint['canaries']:
        fresh = fresh_by_probe.get(stored['probe'])
        if fresh is None:
            status, similarity = 'missing', None
        elif len(fresh) != len(stored['embedding']):
            status, similarity = 'drifted', None
        else:
            a = np.asarray(stored['embedding'], dtype=np.float64)
            b = np.asarray(fresh, dtype=np.float64)
            denominator = float(np.linalg.norm(a) * np.linalg.norm(b))
            similarity = float(np.dot(a, b)) / denominator if denominator else 0.0
            status = 'ok' if similarity >= threshold else 'drifted'
        probes.append({'probe': stored['probe'], 'status': status, 'similarity': similarity})
    similarities = [p['similarity'] for p in probes if p['similarity'] is not None]
    return {
        'ok': all(p['status'] == 'ok' for p in probes),
        'threshold': threshold,
        'probes': probes,
        'meanSimilarity': sum(similarities) / len(similarities) if similarities else None,
    }
