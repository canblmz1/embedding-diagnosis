# embedding-diagnosis — yerel Python alfa

Başlatılmış bir LightRAG Nano deposundaki seçilen kayıtları, uygulamanın gerçek belge embedding çağrısıyla karşılaştıran küçük bileşen. Her kayıt için gerekçeli `match`, `mismatch` veya `unknown` döndürür. Salt okunur örnek tanısıdır; reindex/migration yapmaz.

## Temel kurulum ve API

```bash
python -m pip install .
```

Temel paketin tek üçüncü taraf bağımlılığı NumPy'dır. LightRAG veya yerel model bağımlılıkları temel import sırasında yüklenmez.

```python
import json
from embedding_diagnosis import diagnose, summarize
from embedding_diagnosis.lightrag import LightRAGAdapter

# rag: uygulamanızın başlatılmış, yazmaları tamamlanmış LightRAG nesnesi.
# ids: gerçek native chunk ID'leri.
# threshold: kendi model/depolama koşullarınız için gerekçelendirilmiş tolerans.
adapter = LightRAGAdapter(rag.chunks_vdb)
report = await diagnose(adapter, ids, threshold=threshold)
print(json.dumps(report, ensure_ascii=False, indent=2))
print(summarize(report))
```

Bu en kısa bağlantıda geçmiş encoder girdisine ilişkin kanıt bulunmadığı için okunabilen kayıtlar `original_embedding_input_unverified` gerekçesiyle `unknown` olur ve tanı embedding çağrısı yapmaz. Geçmişteki gerçek girdiyi yalnız bugünkü ayarlardan çıkarmak desteklenmez. Yararlı sayısal karşılaştırma için güvenilir geçmiş girdi bilgisi ve güncel encoder yürütümünün gözlemi ayrıca gerekir.

## Geçmiş kanıtı ve encoder gözlemi olan kullanım

```python
from pathlib import Path

adapter = LightRAGAdapter(
    rag.chunks_vdb,
    observer=encoder,  # Uygulamanın gerçekten kullandığı gözlenebilir sağlayıcı.
    provenance=Path("observed-inputs.json"),
)
report = await diagnose(adapter, ids, threshold=threshold)
```

`provenance`, native kayıt ID'siyle anahtarlanmış geçmiş girdi kanıtı sözlüğü veya bu sözlüğü içeren JSON dosyasıdır. Dosya zorunlu değildir. Eksik, okunamayan veya bozuk dosya; okunabilen indeks kayıtlarını `storage_read_error` yapmaz. Kanıtı doğrulanamayan kayıtlar `original_embedding_input_unverified` olur. Asıl native depolama hatası ayrı `storage_read_error` olarak raporlanır.

Bir girdi kanıtı kaynak metin hash'ini, gerçekten gözlenmiş encoder girdi metnini/hash'ini, document rolünü, uygulanan dönüşümün açıklamasını ve geçmiş gözleme referansı içerir. Bunları bugünkü ayarlardan varsayarak doldurmayın. Örnekteki ileriye dönük kayıtlar **yazma çağrısı sırasında** gözlenen input pozisyonuna bağlanır. Geçmişte gözlenmemiş iki kayda sonradan kanıt üretilmez.

`observer` yoksa, kanıtı olan kayıtlar da taze encoder yürütümü doğrulanamadığı için `unknown` kalır; gözlenemeyen pahalı replay çağrısı yapılmaz. Standart bir Python fonksiyonuna girilmesi veya uzaktaki API'ye istek yapılması tek başına tazelik kanıtı sayılmaz. Uzaktaki sunucunun cache kullanıp kullanmadığı bu bileşen tarafından doğrulanmaz.

### Sağlanan yerel model bağlantısı

```python
from embedding_diagnosis.local_encoder import LocalTransformerEncoder
from lightrag.utils import EmbeddingFunc

encoder = LocalTransformerEncoder("/absolute/path/to/local-model", max_length=128)
embedding_func = EmbeddingFunc(
    embedding_dim=encoder.embedding_dim,
    max_token_size=128,
    func=encoder,
    model_name="sentence-transformers/paraphrase-MiniLM-L3-v2@4ca70771034acceecb2e72475f72050fcdde4ddc",
    supports_asymmetric=True,
)
# embedding_func'u kendi normal LightRAG kurucunuza verin.
# Tanı daha sonra aynı başlatılmış uygulamanın chunks_vdb nesnesine bağlanır.
```

`LocalTransformerEncoder` normal async embedding callable'ıdır ve aynı zamanda gözlemci sağlar. Torch/Transformers yalnız bu sınıf oluşturulduğunda import edilir. Yerel safetensors modeli ve tokenizer yüklenir; uzak kod çalıştırılmaz, otomatik model indirilmez. Bu uygulama CPU'da sıralı tokenizer girdisi, gerçek BERT encoder forward'ı ve attention-mask mean pooling kullanır. Çıktı cache'i içermez ve cache temizlemez. Yazma ve tanı aynı native document çağrı yolunu kullanır.

Tazelik kanıtı, tamamlanan gerçek `model.encoder` forward hook'undan ve bu çağrıya bağlı sıralı girdilerden oluşur. Çağrı kimliği, provider çağrı kimliği, input pozisyonu, token satırı, encoder/config hash'leri ve çıktı satırı hash'i kaydedilir. Aynı metni taşıyan farklı ID'ler metne göre birleştirilmez. Bu alfa tek provider çağrısı ve sıralı tek model forward'ı destekler; bölünen, yeniden sıralanan veya belirsiz eşleşmeler `unknown` olur. Mevcut başka sağlayıcınızı kullanıyorsanız aynı gözlem sözleşmesine uygun bağlantı kodu sizin sorumluluğunuzdadır.

### Kendi gözlemcinizin küçük sözleşmesi

`observer.capture()` bir context manager döndürür ve `embedding_diagnosis.lightrag.Observation` nesnesi sağlar. `call_id` yalnız scope kimliğidir. `provider_calls`, tamamlanan gerçek provider çağrısının kimliğini ve input/output adetlerini taşır. Her input pozisyonu için `events` kaydı; aynı scope/provider kimliği, document rolü, gerçek input hash'i, benzersiz event kimliği ve gözlenen çıktı hash'i içerir. `execution_observed` yalnız gerçek encoder yürütümü gözlendiğinde doldurulur. Doldurulmuş bir sözlüğün doğruluğu otomatik olarak kanıtlanmış olmaz; gözlemci uygulamanın güven sınırıdır.

## Tek tamamlanmış yerel kullanım örneği

Desteklenen native kaynak LightRAG `aaebfe1bb8d55deb6a4304d357a3bf4c92fcd40a` (metadata sürümü 1.5.8), NanoVectorDB 0.0.4.3'tür. Örnek gerçek kullanıcı corpus'u gerektirmez: yeni, ayrı küçük bir native indeks oluşturur; iki yazmada geçmiş input gözlemi tutmaz, iki yazmada açıkça ileriye dönük gözlem tutar; yazıcıyı kapatıp indeksi yeniden açar ve tanı bileşenini sonra bağlar. Bu kontrollü kullanım örneğidir.

Örnekte gerçek Hugging Face tokenizer, LightRAG'in tokenizer arayüzüne bağlanır; eski karakter tokenizer fixture'ı kullanılmaz. Native LightRAG kurucusu bir LLM callable'ı da zorunlu tutar. Bu chunk depolama örneği, çağrılırsa açık hata veren `llm_not_configured` fonksiyonunu sağlar; LLM extraction/generation çalıştırılmaz. Gerçek uygulamanızın mevcut LLM bağlantısı bu tanı için değiştirilmez.

Python 3.12 ile ayrı ortamda kurulum:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install .
.venv/bin/python -m pip install torch==2.5.1+cpu --index-url https://download.pytorch.org/whl/cpu
.venv/bin/python -m pip install transformers==4.57.3 "lightrag-hku @ git+https://github.com/HKUDS/LightRAG.git@aaebfe1bb8d55deb6a4304d357a3bf4c92fcd40a"
python3 integration/download_model.py --download
.venv/bin/python examples/lightrag_local.py --model-dir models/paraphrase-MiniLM-L3-v2 --work-dir runs/my_example
```

Windows'ta venv Python yolu `.venv\Scripts\python.exe` olur; bu tur Windows çalıştırması yapılmadı. Paket wheel dosyasıyla da kurulabilir: `python -m pip install dist/embedding_diagnosis-0.1.0a1-py3-none-any.whl`.

İndirme komutu, teslim edilen sabit model manifest'ini kullanır; dosya boyutlarını ve kaynak blob/SHA-256 değerlerini doğrular. Örneğin ve kurulu paketin model manifest'ine veya araştırma raporlarına runtime bağımlılığı yoktur; mevcut yerel model dizininizi verdiğinizde bu indirme adımı gerekmez. Model ağırlıkları küçük Python wheel'ine eklenmemiştir.

Model: [sentence-transformers/paraphrase-MiniLM-L3-v2](https://huggingface.co/sentence-transformers/paraphrase-MiniLM-L3-v2), sabit revizyon `4ca70771034acceecb2e72475f72050fcdde4ddc`, Apache-2.0. Ağırlık dosyası 69,569,488 byte; seçilen tokenizer/config/card dosyalarıyla indirme 70,272,180 byte'tır. Bu indirmenin yanında Torch ve native uygulama bağımlılıkları da gerekir; model boyutu toplam kurulum boyutu değildir.

Örnek `0.99999` eşiğini bu belirli CPU/model/native Float16 depolama yolu için açıkça bildirir. Ayrı kalibrasyon metinleriyle aynı belge çağrısının tekrarı ve Float16 etkisi kaydedilir. Tanı yapılan kayıtlara bakarak eşiği gevşetmez. Bu eşik bütün modellere önerilen doğrulanmış bir varsayılan değildir; genel API bu yüzden `threshold` parametresini zorunlu ister.

## Salt okunurluk ve destek sınırı

Başlatılmış Nano deposunda bekleyen/kalıcılaştırılmamış upsert veya delete olmamalıdır. Adaptör `_pending_upserts`, `_unsaved_upserts`, `_pending_deletes`, `_unsaved_deletes`, `_client_dirty` alanlarını okur. Bu beş özel alana bağımlılık sürüm bakım maliyetidir; desteklenmeyen depo yapısı sessizce kabul edilmez. Adaptör flush veya write çağırmaz. Eşzamanlı yazıcıların bulunmadığı, yazmaları tamamlanmış yeniden açılmış indeks desteklenir; kilit veya transaction garantisi eklenmez.

Örnek, tanı öncesi/sonrası indeks dosyası hash'lerini karşılaştırır. JSON raporuyla birlikte kısa okunabilir özet ve gerçek provider çağrısı/model forward/metin sayıları üretir. Cache hit'ini gerçek encoder yürütümü olarak raporlamaz.

`match`, seçilen kaydın bildirilen sözleşme/toleransla eşleşmesidir. `mismatch`, bu sözleşme altında yeniden üretilememesidir; kesin model değişimi veya bütün indeksin bozukluğu değildir. `unknown`, kanıt veya gözlemin yetersizliğidir.

## İki hedefli regresyon

```bash
.venv/bin/python -I tests/test_adapter_regressions.py
```

İki test metodu; eksik/bozuk geçmiş kanıtı ile gerçek storage hatasının ayrılmasını ve aynı metinli farklı ID'lerin çağrı/pozisyon/çıktı adediyle eşlenmesini denetler. Küçük unit double'lar kullanır; gerçek model/native çalışma kanıtı örneğin ayrı koşusudur. `tests/reproduce_original_defects.py`, değiştirilmemiş eski adaptörde aynı iki hatayı gösteren, bilerek 1 ile çıkan ayrı kayıttır; normal kullanıcı akışında gerekmez.

## Dify ve önceki sonuç

Dify adaptörü ve önceki deney arşivi değiştirilmeden korunur; eski Dify kendi eski `shared` çekirdeğiyle çalışır. Bu alfadaki zorunlu `threshold` argümanı eski Dify çağrılarına otomatik uygulanmış değildir. Gelecekteki bir port açık threshold gerektirir; bu tur yeni Dify runtime doğrulaması yapılmadı. Cosine mekanizmasının fonksiyon kaynağı ve ortak tanı gövdesinin davranışı korundu; araştırma dosyası okuyan eski standalone runner pakete alınmadı.

PyPI yayını, upstream PR, otomatik reindex/migration, üçüncü uygulama adaptörü, kullanıcı benimsenmesi ve üretim uygunluğu bu alfanın kapsamı değildir.
